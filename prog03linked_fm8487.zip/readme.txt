First download the zip folder.
Then unzip by clicking extracting and extracting the contents into another folder
Run the program in Linux by using the make command on the makefile: "make -f makefile"
Then run the executable for typing it on the command line: "./StackFun"
Your program should now be running
